Set objNet = WScript.CreateObject("WScript.Network");
Set objShell = WScript.CreateObject("WScript.Shell");
Set colUsrEuvVars = objShellEnvironment("USER");
colUsrEnvVars("CURR_LOGIN") = objNetwork.UserName;
Wscript.Echo colUsrVars("CURR_LOGIN");