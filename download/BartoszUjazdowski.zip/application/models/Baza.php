<?php
class baza extends CI_Model {
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }    
       
    public function add_user($email, $password, $birthday)
    {
        $dane = array(  'id' => '',
                        'email' => $email,
						'haslo' => $password,
                        'dataUr' => $birthday);
        
        $this->db->insert('users', $dane);
    }     
            
    public function auth_me($email, $pass)
    {
        return $this->db->query('SELECT id FROM users WHERE email = \''.$email.'\' AND haslo = \''.$pass.'\'');
    }    
	
	public function getEmail($user_id)
	{
        $this->db->select('email');
        $this->db->from('users');
        $this->db->where('users.id', $user_id);
        $query = $this->db->get();
        
        return $query->result();
	}
	public function getBirthday($user_id)
	{
        $this->db->select('dataUr');
        $this->db->from('users');
        $this->db->where('users.id', $user_id);
        $query = $this->db->get();
        
        return $query->result();
	}
}
