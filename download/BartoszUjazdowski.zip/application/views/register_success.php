 <h4 class="panel-title">Gratulacje!</h4>
 <p class="flow-text">Rejestracja przebiegła pomyślnie! Możesz się teraz zalogować na swoje konto.</p>
       