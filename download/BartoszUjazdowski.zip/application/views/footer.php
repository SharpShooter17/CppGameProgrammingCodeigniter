<footer class="page-footer light-green">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Rekrutacja</h5>
                <p class="grey-text text-lighten-4">Strone wykonał Bartosz Ujazdowski</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Kontakt</h5>
                <p class="grey-text text-lighten-3"><i class="small material-icons">email</i> e-mail: b.ujazdowski@gmail.com</p>
                <p class="grey-text text-lighten-3"><i class="small material-icons">contact_phone</i> Nr. tel: 732-945-210</p>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
            	Wszystkie prawa zastrzeżone © 2017
            </div>
          </div>
</footer>