<?php
if ($this->session->userdata('logged_in') == FALSE) {
    redirect(site_url(''));
}
?>
<!DOCTYPE html>
<html >
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

        <title>Broccoli Tool</title>

        <link rel="stylesheet" type="text/css" href="<?= site_url('../application/assets/css/error.css') ?>" >
        <link rel="stylesheet" type="text/css" href="<?= site_url('../application/assets/css/main.css') ?>" >
        <link rel="stylesheet" type="text/css" href="<?= site_url('../application/assets/css/navbar.css') ?>" >
        <link rel="stylesheet" type="text/css" href="<?= site_url('../application/assets/css/bootstrap.min.css') ?>" >
        <link rel="stylesheet" type="text/css" href="<?= site_url('../application/assets/css/font-awesome.min.css') ?>" >

    </head>
    <body>
        <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <img id="logo" src="<?= site_url('../application/assets/img/broccoli.jpg') ?>" alt="logo" class="img-circle img-responsive">
                </div>
                <div class="navbar-brand">
                    Broccoli Tool
                </div>
                <ul class="nav navbar-nav nav-right">
                    <li class="link"><a href="<?php echo site_url('MainController/'); ?>">Back</a></li>
                    <li class="link"><a href="<?php echo site_url('LoginController/logout'); ?>">Logout</a></li>
                    <li id="login-id"><b><?php echo $this->session->userdata('uid'); ?></b></li>
                </ul>
            </div>

        </nav>

        <div id="contener" style="background-color: red !important;" class="center-block text-center">
            <?= $error_message ?>
            <img src="<?= site_url('../application/assets/img/Minionsad.gif') ?>" />
            <hr />
            <a class="btn btn-warning btn-block" href="<?php echo site_url('MainController/'); ?>">Back (redirect <span id="autoRedirect">3</span> )</a>
        </div>


        <!--SCRIPT-->
        <script src="<?= site_url('../application/assets/js/jquery-2.1.1.min.js') ?>"></script>
        <script src="<?= site_url('../application/assets/js/bootstrap.min.js') ?>"></script>
    </body>

    <script type="text/javascript">
        //odliczanie    
        setInterval(function () {
            $('#autoRedirect').text( $('#autoRedirect').text() - 1);
        }, 1000);
        //przekierowanie
        setTimeout(function () {
            window.location.href = "<?php echo site_url('MainController/'); ?>";
        },
                3000);
    </script>