<nav>
	<div class="nav-wrapper light-green">
		<ul id="nav" class="right hide-on-med-and-down">
			<li>
				<a href='<?php echo site_url('/') ?>'>Strona główna</a>
			</li>
			<?php if (!$logged):
			?>
			<li>
				<a href='<?php echo site_url('/register/') ?>'>Zarejestruj się</a>
			</li>
			<li>
				<a href='<?php echo site_url('/login/'); ?>'>Zaloguj się</a>
			</li>
			<?php else: ?>
			<li>
				<a href='<?php echo site_url('/login/logout/'); ?>'>Wyloguj się</a>
			</li>
			<?php endif; ?>
		</ul>
	</div>
</nav>