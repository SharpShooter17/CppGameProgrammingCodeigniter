<div class="row">
	<?php if (!$logged): ?>
	Jesteś nie zalogowany! 
	<?php else: ?>
	Jesteś poprawnie zalogowany.
	<p>Twój email to: <?php echo $email; ?></p>
	<p>Twoja data urodzin to:<?php echo $birthday; ?></p>
	<p>Do Twoich urodzin pozostało: <?php echo $timeToBirthday; ?> dni</p>
	<?php endif; ?>
</div>
