<h3>Zarejestruj się!</h3>

<div class="divider"></div>

<?php echo validation_errors(); ?>
<?php echo form_open('register'); ?>

<div class="row">

	<div class="input-field col s12 m6">
		<i class="material-icons prefix">email</i>
		<input type="email" class="validate" name="email" placeholder="Podaj swój email" value="<?=set_value('email') ?>">
		<label for="email">Email</label>
	</div>
	
	<div class="input-field col s12 m6">
		<i class="material-icons prefix">lock</i>
		<input type="password" class="validate" name="password" placeholder="Podaj swoje hasło">
		<label for="password">Hasło</label>
	</div>
</div>

<div class="row">
	
	<div class="input-field col s12 m6">
		<input type="date" name="birthday" class="datepicker">
		<label for="date">Data urodzenia</label>
	</div>
	
</div>
<div class="row">
	<div class="col s12 center-align">
		<button type="reset" name="Reset" class="btn">Wyczyść</button>
		<button type="submit" name="wyslij" class="btn">Zarejestruj się</button>
	</div>
</div>

<?php echo form_close(); ?>

<script>
 $('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 200, // Creates a dropdown of 15 years to control year
	format: 'yyyy-mm-dd',
	min: [1900,1,1],
	max: new Date()
  });
</script>