<?php

class register extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
		$this->load->library('template');
    }
	
	public function pass($password){
		$score = 0;
		$conditionsMeet = 0;
		//1
		$len = strlen($password);
		if ( $len >= 6 ){
			$score += floor($len/2);
			$conditionsMeet++;
		}
		//2
		if ( strtolower($password) != $password ){
			$score += 6;
			$conditionsMeet++;
		}
		//3
		$hits = 0;
		preg_match_all('/[0-9]/', $password, $hits);
		if ($hits > 0) {
			$score += 8;
			$conditionsMeet++;
		}
		//4
		$hits = 0;
		preg_match_all('}{][=+\\|_-)(*&^%$#@!~`/?><', $password, $hits);
		if ($hits > 0) {
			$score += 13;
			$conditionsMeet++;
		}
		//5
		if ($conditionsMeet > 0) {
			$score += ($conditionsMeet*4);
		}
		if ( $score >= 50 ){
			return 100;
		} else {
			return $score * 2;
		}
	}

    public function index() {
        $this->load->helper(array('form', 'url'));

        if ($this->session->userdata('logged_in')) {
            redirect('welcome');
        }

        $this->load->model('baza');

        $this->load->library('form_validation');
        $this->form_validation->set_rules('birthday', 'birthday', 'trim|required|exact_length[10]');
        $this->form_validation->set_rules('password', 'password', 'trim|required');
        $this->form_validation->set_rules('email', 'email', 'trim|required|valid_email|is_unique[users.email]');

        $data['logged'] = $this->session->userdata('logged_in');
    	
		$this->template->write('title', 'Zarejestruj się');
		$this->template->write_view('menu', 'menu', $data);
		$this->template->write_view('footer', 'footer');
	
        if ($this->form_validation->run() == FALSE) {
        	$this->template->write_view('content', 'register_form', $data);
        } else {
            $this->baza->add_user($this->input->post('email'), $this->input->post('password'),  $this->input->post('birthday'));
			 $this->template->write_view('content', 'register_success', $data);
        }
		$this->template->render();
    }

}
