
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->library('session');
		$this->load->helper('url');		
		$this->load->library('template');
		$this->load->model('baza');
    }
    
	private function timeToBirthday($birthday){
		$monthBirth = date('m', strtotime($birthday));
		$dayBirth = date('d', strtotime($birthday));
		
		if (date('m') < $monthBirth ) {
			$year = date('Y');
		} else if ( date('m') == $monthBirth && date('d') < $dayBirth){
			$year = date('Y');
		} else if ( date('m') == $monthBirth && date('d') > $dayBirth ) {
			$year = date('Y') + 1;
		} else if ( date('m') == $monthBirth && date('d') == $dayBirth ) {
			return 0;
		} else if (date('m') > $monthBirth) {
			$year = date('Y') + 1;
		}
		
		$birth = strtotime($year.'-'.$monthBirth.'-'.$dayBirth);
		$toDay = strtotime(date('Y-m-d'));
		return round(abs($birth-$toDay)/(60*60*24));
	}
	
	public function index()	{                    
            $data['logged'] = $this->session->userdata('logged_in');
			if ($data['logged'] == TRUE)
			{
				$data['email'] = $this->baza->getEmail($this->session->userdata('id'))[0]->email;
				$data['birthday'] = $this->baza->getBirthday($this->session->userdata('id'))[0]->dataUr;
				$data['timeToBirthday'] = $this->timeToBirthday( $data['birthday'] );
			}
			
			$this->template->write('title', 'Rekrutacja');
			$this->template->write_view('menu', 'menu', $data);
			$this->template->write_view('content', 'welcome', $data);
			$this->template->write_view('footer', 'footer');
			$this->template->render();
	}
}
?>